-- MySQL dump 10.13  Distrib 5.7.23-23, for Linux (x86_64)
--
-- Host: localhost    Database: nutrient_db
-- ------------------------------------------------------
-- Server version	5.7.23-23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagem` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razaosocial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` int(11) NOT NULL,
  `noticias_id` int(10) unsigned NOT NULL,
  `produtos_id` int(10) unsigned NOT NULL,
  `linhas_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `banners_noticias_id_foreign` (`noticias_id`),
  KEY `banners_produtos_id_foreign` (`produtos_id`),
  KEY `banners_linhas_id_foreign` (`linhas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cpfcnpj` varchar(23) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razaosocial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomefantasia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logradouro` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rep_nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rep_cpf` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `informacoesnutricionais`
--

DROP TABLE IF EXISTS `informacoesnutricionais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informacoesnutricionais` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `elemento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valores` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produtos_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `informacoesnutricionais_produtos_id_foreign` (`produtos_id`)
) ENGINE=MyISAM AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `informacoesnutricionais`
--

LOCK TABLES `informacoesnutricionais` WRITE;
/*!40000 ALTER TABLE `informacoesnutricionais` DISABLE KEYS */;
INSERT INTO `informacoesnutricionais` (`id`, `elemento`, `valores`, `produtos_id`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Sódio','140g',1,'2020-06-06 17:40:57','2020-06-06 17:40:57',NULL),(2,'Cálcio','170g',1,'2020-06-06 17:42:42','2020-06-06 17:42:42',NULL),(3,'Fósforo','90g',1,'2020-06-06 17:43:30','2020-06-06 17:43:30',NULL),(4,'Enxofre','25g',1,NULL,NULL,NULL),(5,'Cromo','40mg',1,NULL,NULL,NULL),(6,'Zinco','5.000mg',1,NULL,NULL,NULL),(7,'Cobre','2.000mg',1,NULL,NULL,NULL),(8,'Cobalto','100mg',1,NULL,NULL,NULL),(9,'Iodo','90mg',1,NULL,NULL,NULL),(10,'Selênio','45mg',1,NULL,NULL,NULL),(11,'Sódio','160g',2,NULL,NULL,NULL),(12,'Cálcio','140g',2,NULL,NULL,NULL),(13,'Fósforo','80g',2,NULL,NULL,NULL),(14,'Enxofre','16g',2,NULL,NULL,NULL),(15,'Magnésio','2mg',2,NULL,NULL,NULL),(16,'Manganês','200mg',2,NULL,NULL,NULL),(17,'Zinco','5.000mg',2,NULL,NULL,NULL),(18,'Cobre','1.500mg',2,NULL,NULL,NULL),(19,'Cobalto','125mg',2,NULL,NULL,NULL),(20,'Iodo','90mg',2,NULL,NULL,NULL),(21,'Selênio','22,5mg',2,NULL,NULL,NULL),(22,'Sódio','131g',3,NULL,NULL,NULL),(23,'Cálcio','170g',3,NULL,NULL,NULL),(24,'Fósforo','100g',3,NULL,NULL,NULL),(25,'Enxofre','18g',3,NULL,NULL,NULL),(26,'Magnésio','15mg',3,NULL,NULL,NULL),(27,'Manganês','1.250mg',3,NULL,NULL,NULL),(28,'Zinco','5.000mg',3,NULL,NULL,NULL),(29,'Cobre','1.750mg',3,NULL,NULL,NULL),(30,'Cobalto','125mg',3,NULL,NULL,NULL),(31,'Iodo','45mg',3,NULL,NULL,NULL),(32,'Selênio','45mg',3,NULL,NULL,NULL),(33,'Sódio','180g',4,NULL,NULL,NULL),(34,'Cálcio','145g',4,NULL,NULL,NULL),(35,'Fósforo','65g',4,NULL,NULL,NULL),(36,'Enxofre','10g',4,NULL,NULL,NULL),(37,'Magnésio','2g',4,NULL,NULL,NULL),(38,'Manganês','40mg',4,NULL,NULL,NULL),(39,'Zinco','5.000mg',4,NULL,NULL,NULL),(40,'Cobre','2.000mg',4,NULL,NULL,NULL),(41,'Cobalto','10mg',4,NULL,NULL,NULL),(42,'Iodo','90mg',4,NULL,NULL,NULL),(43,'Selênio','45mg',4,NULL,NULL,NULL),(44,'Sódio','195g',5,NULL,NULL,NULL),(45,'Cálcio','118g',5,NULL,NULL,NULL),(46,'Fósforo','60g',5,NULL,NULL,NULL),(47,'Enxofre','25g',5,NULL,NULL,NULL),(48,'Magnésio','2,5g',5,NULL,NULL,NULL),(49,'Zinco','5.000mg',5,NULL,NULL,NULL),(50,'Cobre','1.500mg',5,NULL,NULL,NULL),(51,'Cobalto','140mg',5,NULL,NULL,NULL),(52,'Iodo','90mg',5,NULL,NULL,NULL),(53,'Selênio','22,5mg',5,NULL,NULL,NULL),(54,'Sódio','151,31g',6,NULL,NULL,NULL),(55,'Cálcio','152,76g',6,NULL,NULL,NULL),(56,'Fósforo','85g',6,NULL,NULL,NULL),(57,'Enxofre','16g',6,NULL,NULL,NULL),(58,'Magnésio','3g',6,NULL,NULL,NULL),(59,'Manganês','250mg',6,NULL,NULL,NULL),(60,'Zinco','5.000mg',6,NULL,NULL,NULL),(61,'Cobre','1.750mg',6,NULL,NULL,NULL),(62,'Cobalto','125mg',6,NULL,NULL,NULL),(63,'Iodo','120mg',6,NULL,NULL,NULL),(64,'Selênio','45mg',6,NULL,NULL,NULL),(65,'Cálcio','260g',7,NULL,NULL,NULL),(66,'Fósforo','160g',7,NULL,NULL,NULL),(67,'Enxofre','30g',7,NULL,NULL,NULL),(68,'Magnésio','5g',7,NULL,NULL,NULL),(69,'Manganês','350mg',7,NULL,NULL,NULL),(70,'Zinco','10.080mg',7,NULL,NULL,NULL),(71,'Cobre','3.000mg',7,NULL,NULL,NULL),(72,'Cobalto','250mg',7,NULL,NULL,NULL),(73,'Iodo','180mg',7,NULL,NULL,NULL),(74,'Selênio','45mg',7,NULL,NULL,NULL),(75,'Sódio','130g',8,NULL,NULL,NULL),(76,'Cálcio','110g',8,NULL,NULL,NULL),(77,'Fósforo','60g',8,NULL,NULL,NULL),(78,'Enxofre','35g',8,NULL,NULL,NULL),(79,'Magnésio','27g',8,NULL,NULL,NULL),(80,'Zinco','4.300mg',8,NULL,NULL,NULL),(81,'Cobre','370mg',8,NULL,NULL,NULL),(82,'Cobalto','160mg',8,NULL,NULL,NULL),(83,'Iodo','300mg',8,NULL,NULL,NULL),(84,'Selênio','45mg',8,NULL,NULL,NULL),(85,'PB','15%',9,NULL,NULL,NULL),(86,'NDT','70%',9,NULL,NULL,NULL),(87,'Cálcio','1,2%',9,NULL,NULL,NULL),(88,'Fósforo','0,6%',9,NULL,NULL,NULL),(89,'Sódio','86,48g',14,NULL,NULL,NULL),(90,'Cálcio','48,42g',14,NULL,NULL,NULL),(91,'Fósforo','40g',14,NULL,NULL,NULL),(92,'Enxofre','14g',14,NULL,NULL,NULL),(93,'Manganês','500mg',14,NULL,NULL,NULL),(94,'Ferro','500mg',14,NULL,NULL,NULL),(95,'Zinco','2.000mg',14,NULL,NULL,NULL),(96,'Cobre','500mg',14,NULL,NULL,NULL),(97,'Cobalto','60mg',14,NULL,NULL,NULL),(98,'Iodo','80mg',14,NULL,NULL,NULL),(99,'Selênio','20mg',14,NULL,NULL,NULL),(100,'Proteína Bruta','20mg',14,NULL,NULL,NULL),(101,'NNP(max)','20mg',14,NULL,NULL,NULL),(102,'Sódio','25g',15,NULL,NULL,NULL),(103,'Cálcio','15g',15,NULL,NULL,NULL),(104,'Fósforo','8g',15,NULL,NULL,NULL),(105,'Enxofre','5g',15,NULL,NULL,NULL),(106,'Zinco','300mg',15,NULL,NULL,NULL),(107,'Cobre','90mg',15,NULL,NULL,NULL),(108,'Cobalto','8mg',15,NULL,NULL,NULL),(109,'Iodo','7mg',15,NULL,NULL,NULL),(110,'Selênio','3mg',15,NULL,NULL,NULL),(111,'Proteína Bruta','30%',15,NULL,NULL,NULL),(112,'NNP(max)','30g',15,NULL,NULL,NULL),(113,'NDT','65%',15,NULL,NULL,NULL),(114,'Sódio','30g',16,NULL,NULL,NULL),(115,'Cálcio','20g',16,NULL,NULL,NULL),(116,'Fósforo','12,5g',16,NULL,NULL,NULL),(117,'Enxofre','6g',16,NULL,NULL,NULL),(118,'Magnésio','1,5g',16,NULL,NULL,NULL),(119,'Manganês','120g',16,NULL,NULL,NULL),(120,'Zinco','480mg',16,NULL,NULL,NULL),(121,'Cobre','168mg',16,NULL,NULL,NULL),(122,'Cobalto','12mg',16,NULL,NULL,NULL),(123,'Iodo','11mg',16,NULL,NULL,NULL),(124,'Selênio','4mg',16,NULL,NULL,NULL),(125,'Proteína Bruta','30%',16,NULL,NULL,NULL),(126,'NNP(max)','30g',16,NULL,NULL,NULL),(127,'Vit. A','10.000 UI',16,NULL,NULL,NULL),(128,'Vit. E','75mg',16,NULL,NULL,NULL),(129,'NDT','65%',16,NULL,NULL,NULL),(130,'Sódio','95g',17,NULL,NULL,NULL),(131,'Cálcio','95g',17,NULL,NULL,NULL),(132,'Fósforo','60g',17,NULL,NULL,NULL),(133,'Enxofre','19,5g',17,NULL,NULL,NULL),(134,'Magnésio','5g',17,NULL,NULL,NULL),(135,'Manganês','500g',17,NULL,NULL,NULL),(136,'Zinco','2.500mg',17,NULL,NULL,NULL),(137,'Cobre','1.220mg',17,NULL,NULL,NULL),(138,'Cobalto','80mg',17,NULL,NULL,NULL),(139,'Iodo','60mg',17,NULL,NULL,NULL),(140,'Selênio','10mg',17,NULL,NULL,NULL),(141,'Proteína Bruta','25%',17,NULL,NULL,NULL),(142,'NNP(max)','33,7g',17,NULL,NULL,NULL),(143,'Fósforo','18g',18,NULL,NULL,NULL),(144,'Enxofre','7g',18,NULL,NULL,NULL),(145,'Zinco','1.080mg',18,NULL,NULL,NULL),(146,'Cobre','250mg',18,NULL,NULL,NULL),(147,'Cobalto','23mg',18,NULL,NULL,NULL),(148,'Iodo','30mg',18,NULL,NULL,NULL),(149,'Selênio','10mg',18,NULL,NULL,NULL),(150,'Proteína Bruta','40%',18,NULL,NULL,NULL),(151,'NNP(max)','90g',18,NULL,NULL,NULL),(152,'NDT','52%',18,NULL,NULL,NULL),(153,'Sódio','55g',18,NULL,NULL,NULL),(154,'Sódio','95g',19,NULL,NULL,NULL),(155,'Cálcio','97g',19,NULL,NULL,NULL),(156,'Fósforo','60g',19,NULL,NULL,NULL),(157,'Enxofre','20g',19,NULL,NULL,NULL),(158,'Magnésio','8,25g',19,NULL,NULL,NULL),(159,'Manganês','500g',19,NULL,NULL,NULL),(160,'Zinco','2.500mg',19,NULL,NULL,NULL),(161,'Cobre','1.220mg',19,NULL,NULL,NULL),(162,'Cobalto','80mg',19,NULL,NULL,NULL),(163,'Iodo','60mg',19,NULL,NULL,NULL),(164,'Selênio','23mg',19,NULL,NULL,NULL),(165,'Proteína Bruta','25%',19,NULL,NULL,NULL),(166,'NNP(max)','33,7g',19,NULL,NULL,NULL),(167,'Sódio','125g',20,NULL,NULL,NULL),(168,'Cálcio','117g',20,NULL,NULL,NULL),(169,'Fósforo','70g',20,NULL,NULL,NULL),(170,'Enxofre','5g',20,NULL,NULL,NULL),(171,'Zinco','2.160mg',20,NULL,NULL,NULL),(172,'Cobre','800mg',20,NULL,NULL,NULL),(173,'Cobalto','60mg',20,NULL,NULL,NULL),(174,'Iodo','42mg',20,NULL,NULL,NULL),(175,'Selênio','24mg',20,NULL,NULL,NULL),(176,'Proteína Bruta','15%',20,NULL,NULL,NULL),(177,'NNP(max)','23g',20,NULL,NULL,NULL),(178,'Sódio','35g',21,NULL,NULL,NULL),(179,'Cálcio','50g',21,NULL,NULL,NULL),(180,'Fósforo','40g',21,NULL,NULL,NULL),(181,'Manganês','1.200g',21,NULL,NULL,NULL),(182,'Ferro','220mg',21,NULL,NULL,NULL),(183,'Zinco','4.700mg',21,NULL,NULL,NULL),(184,'Cobre','950mg',21,NULL,NULL,NULL),(185,'Cobalto','50mg',21,NULL,NULL,NULL),(186,'Iodo','110mg',21,NULL,NULL,NULL),(187,'Selênio','25mg',21,NULL,NULL,NULL),(188,'Proteína Bruta','18%',21,NULL,NULL,NULL),(189,'Extrato Etéreo','2,6%',21,NULL,NULL,NULL),(190,'Fibra Bruta (max)','10%',21,NULL,NULL,NULL),(191,'NDT','54%',21,NULL,NULL,NULL);
/*!40000 ALTER TABLE `informacoesnutricionais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linhas`
--

DROP TABLE IF EXISTS `linhas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linhas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `capa` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `embalagem` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linhas`
--

LOCK TABLES `linhas` WRITE;
/*!40000 ALTER TABLE `linhas` DISABLE KEYS */;
INSERT INTO `linhas` (`id`, `nome`, `descricao`, `capa`, `embalagem`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Sal Mineral','<p>Uma tend&ecirc;ncia observada na nutri&ccedil;&atilde;o animal aplicada, em todo mundo, &eacute; o aumento da demanda por minerais dos animais a pasto em fun&ccedil;&atilde;o do maior potencial gen&eacute;tico para a produ&ccedil;&atilde;o de leite e carne, do controle das enfermidades e da ado&ccedil;&atilde;o de novas t&eacute;cnicas de manejo das pastagens. Todavia, ainda que o manejo seja excelente, as pastagens mesmo na &eacute;poca chuvosa do ano, n&atilde;o fornecem aos animais quantidades de minerais suficiente para o pleno crescimento, lacta&ccedil;&atilde;o, reprodu&ccedil;&atilde;o e para a defesa contra infec&ccedil;&otilde;es. Al&eacute;m disso as defici&ecirc;ncias dos pastos podem ser agravadas pelo envelhecimento dos mesmos. A equipe t&eacute;cnica da AgroSal, atrav&eacute;s de diversas an&aacute;lises foliares da Regi&atilde;o Tocantina e Sudeste Paraense, visando sempre baixar os custos e maximizar a produtividade pecu&aacute;ria na regi&atilde;o, desenvolveu formula&ccedil;&otilde;es que suprem de maneira econ&ocirc;mica e eficiente as car&ecirc;ncias nutricionais nestas &aacute;reas. Os gr&aacute;ficos abaixo comparam as exig&ecirc;ncias minerais dos bovinos de corte (1 UA/ manuten&ccedil;&atilde;o) com as m&eacute;dias destes minerais presentes nas pastagens destas regi&otilde;es.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://web.archive.org/web/20181228081030im_/http://nutrientesagrosal.com.br/photos/1/grafico_branca-copy.jpg\" alt=\"\" /></p>','1531397019.linha-branca.png','1591728407.1537369978.1531397766.60.png','Sal-Mineral',NULL,'2020-06-09 21:46:47',NULL),(2,'Linha Proteinados','<p>A melhor estrat&eacute;gia de uso da suplementa&ccedil;&atilde;o nutricional dos bovinos em condi&ccedil;&otilde;es de pastejo tem como ponto b&aacute;sico o procedimento t&eacute;cnico, que ir&aacute; orientar o pecuarista a tomar a decis&atilde;o correta frente &agrave;s condi&ccedil;&otilde;es do meio (per&iacute;odo da chuva ou seca)&rdquo;.</p>\r\n<h3><strong>PORQUE SUPLEMENTAR NA SECA?</strong></h3>\r\n<p>Durante a &eacute;poca seca do ano, a forrageira que j&aacute; era deficiente em minerais, passa a ser tamb&eacute;m deficiente em energia e prote&iacute;na sendo este o fator nutricional mais limitante nessa &eacute;poca. O bovino diminui a rumina&ccedil;&atilde;o e a ingest&atilde;o de forragem quando a dieta n&atilde;o cont&eacute;m 7% de Prote&iacute;na bruta na mat&eacute;ria seca e as forrageiras tropicais na seca podem chegar a 4,5% . Os Proteinados corrigem as defici&ecirc;ncias, pois cont&eacute;m em sua formula&ccedil;&atilde;o Prote&iacute;na, Energia e Minerais essenciais e adequadamente balanceados. Propicia um maior consumo e aproveitamento da forragem, pois favorece a funcionalidade ruminal, ocasionando o fim do &ldquo;efeito sanfona&rdquo;.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://web.archive.org/web/20181228081038im_/http://nutrientesagrosal.com.br/photos/1/grafico.png\" alt=\"\" /></p>','1531397176.linha-proteinados.png',NULL,'Linha-Proteinados',NULL,'2020-06-09 21:44:03',NULL),(3,'Linha de Rações','<p>A Agrosal n&atilde;o mede esfor&ccedil;os para oferecer aos seus clientes uma completa linha de ra&ccedil;&otilde;es fareladas, que s&atilde;o fabricadas com mat&eacute;rias primas selecionadas que cont&eacute;m nutrientes de alta digestibilidade.</p>\r\n<p>A nossa linha de ra&ccedil;&otilde;es &eacute; fabricada sob encomenda, o que garante uma maior qualidade do produto final.</p>','1531397253.linha-equinas-e-caprinas.png',NULL,'Linha-de-Racoes',NULL,'2020-06-09 21:43:47',NULL);
/*!40000 ALTER TABLE `linhas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_02_24_193331_create_cliente_table',1),(4,'2018_04_11_132652_create_informacoesnutricionais_table',1),(5,'2018_05_07_043835_create_quemsomos_table',1),(6,'2018_05_07_043956_create_banners_table',1),(7,'2018_05_07_044029_create_noticias_table',1),(8,'2018_05_07_044111_create_linhas_table',1),(9,'2018_05_07_044151_create_produtos_table',1),(10,'2018_05_08_132750_add_foreign_keys_to_Informacoesnutricionais_table',1),(11,'2018_05_08_132750_add_foreign_keys_to_banners_table',1),(12,'2018_05_08_132750_add_foreign_keys_to_produtos_table',1),(13,'2018_10_03_145210_add_campos_to_quemsomos',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `noticias`
--

DROP TABLE IF EXISTS `noticias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `noticias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conteudo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `palavraschave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datapublicacao` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `noticias`
--

LOCK TABLES `noticias` WRITE;
/*!40000 ALTER TABLE `noticias` DISABLE KEYS */;
INSERT INTO `noticias` (`id`, `titulo`, `descricao`, `conteudo`, `slug`, `palavraschave`, `capa`, `datapublicacao`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Brasil ganha certificado como país livre e febre aftosa com vacinação',NULL,'<p>BRAS&Iacute;LIA - Enquanto trava dura batalha com os europeus, que restringiram as importa&ccedil;&otilde;es de frango e pescados, o Brasil recebe quinta-feira certificado de pa&iacute;s livre da febre aftosa, concedido pela Organiza&ccedil;&atilde;o Mundial de Sa&uacute;de Animal (OIE), com sede em Paris. A aftosa &eacute; uma doen&ccedil;a que ataca bovinos e outros animais de casco bipartido. Seu controle facilita a abertura de mercados para exporta&ccedil;&atilde;o.</p>\r\n<p>&ldquo;O novo status sanit&aacute;rio concedido por esta renomada organiza&ccedil;&atilde;o representa o reconhecimento da vit&oacute;ria de uma longa e dura trajet&oacute;ria de muita dedica&ccedil;&atilde;o de pecuaristas e do setor veterin&aacute;rio oficial brasileiro&rdquo;, disse o ministro da Agricultura, Blairo Maggi, em discurso ontem na cerim&ocirc;nia de abertura da 86&ordf; assembleia da OIE.&nbsp;</p>\r\n<p>O certificado atestar&aacute; que a febre aftosa est&aacute; controlada em todo o territ&oacute;rio brasileiro, por meio da aplica&ccedil;&atilde;o de vacinas. &ldquo;Nosso novo grande desafio ser&aacute; enfrentar a etapa final do processo de erradica&ccedil;&atilde;o da doen&ccedil;a em nosso Pa&iacute;s e na Am&eacute;rica do Sul, ampliar nossas zonas livres sem vacina&ccedil;&atilde;o e, em especial no Brasil, alcan&ccedil;ar a condi&ccedil;&atilde;o de pa&iacute;s livre da febre aftosa sem vacina&ccedil;&atilde;o&rdquo;, afirmou o ministro.</p>\r\n<p>Para chegar a essa condi&ccedil;&atilde;o, reconheceu Maggi, &eacute; preciso avan&ccedil;ar na preven&ccedil;&atilde;o, vigil&acirc;ncia e resposta a emerg&ecirc;ncias que venham a ocorrer. &ldquo;Ser&atilde;o necess&aacute;rios muito mais investimentos no servi&ccedil;o veterin&aacute;rio&rdquo;.</p>\r\n<p>Maggi esteve na semana passada na China e iniciou conversas para vender outros produtos de origem bovina, como carne termicamente processada, cuja venda s&oacute; ser&aacute; poss&iacute;vel por causa do certificado a ser emitido pela OIE. Em reuni&atilde;o com a &aacute;rea da aduana que trata de controle sanit&aacute;rio, foi tratada a exporta&ccedil;&atilde;o de mi&uacute;dos e carne com osso, al&eacute;m de outros itens como arroz, frutas e l&aacute;cteos.</p>\r\n<p>Uma miss&atilde;o t&eacute;cnica chinesa vir&aacute; ao Brasil no fim de maio ou in&iacute;cio de junho para vistoriar frigor&iacute;ficos. A expectativa &eacute; que at&eacute; 84 plantas sejam autorizadas e exportar para aquele pa&iacute;s. Al&eacute;m disso, na semana passada o governo da Coreia do Sul anunciou que come&ccedil;ar&aacute; a importar carne su&iacute;na do Brasil, um mercado potencial de US$ 1,5 bilh&atilde;o.</p>\r\n<p>Segundo Maggi, a pecu&aacute;ria representou Valor Bruto da Produ&ccedil;&atilde;o de R$ 175 bilh&otilde;es em 2017. As exporta&ccedil;&otilde;es do complexo carne aumentaram 8,9%, somando US$ 15,5 bilh&otilde;es.&nbsp;</p>\r\n<p><strong>Restri&ccedil;&otilde;es.</strong>&nbsp;Por outro lado, o controle brasileiro sobre a produ&ccedil;&atilde;o de prote&iacute;na animal t&ecirc;m sido duramente questionado pela Europa. Na semana passada, a Uni&atilde;o Europeia bloqueou a compra de frango de 20 frigor&iacute;ficos locais por suspeita de uso de laudos sanit&aacute;rios falsos. Tamb&eacute;m informou que vai descredenciar as plantas exportadoras de peixe. Nesse caso, porque as embarca&ccedil;&otilde;es n&atilde;o atendem padr&otilde;es exigidos pelo bloco.</p>\r\n<p>&ldquo;Isso n&atilde;o &eacute; implic&acirc;ncia da UE&rdquo;, disse o consultor Pedro de Camargo Neto, ex-presidente da Sociedade Rural Brasileira. &ldquo;O problema &eacute; a lentid&atilde;o do Brasil em mostrar sua sanidade.&rdquo;</p>\r\n<p>Ele observou que a opera&ccedil;&atilde;o Carne Fraca j&aacute; tem mais de um ano, mas o Pa&iacute;s segue com fragilidades no controle sanit&aacute;rio. Por causa disso, os EUA fecharam seu mercado &agrave; carne bovina in natura e at&eacute; hoje n&atilde;o retomaram suas importa&ccedil;&otilde;es.</p>\r\n<p>&nbsp;</p>\r\n<p>FONTE:&nbsp;https://economia.estadao.com.br/noticias/geral,brasil-passa-a-ser-considerado-livre-de-febre-aftosa,70002317061</p>','Brasil-ganha-certificado-como-pais-livre-e-febre-aftosa-com-vacinacao',NULL,'1591727646.1535167726.1531407053.gado0021.jpg','2018-07-12','2020-06-09 21:34:06','2020-06-09 21:34:06',NULL),(2,'Alta na arroba do boi não está refletindo no preço das carnes',NULL,'<p>Mesmo com a firmeza da arroba do boi, o pre&ccedil;o das carnes se mant&eacute;m em queda neste in&iacute;cio de julho, aponta o Centro de Estudos Avan&ccedil;ados em Economia Aplicada (Cepea). No acumulado do m&ecirc;s, contabilizado at&eacute; o dia 11 de julho, a carca&ccedil;a casada bovina registra desvaloriza&ccedil;&atilde;o de 0,94%, sendo negociada a R$ 9,50 por quilo, na Grande S&atilde;o Paulo.</p>\r\n<p>A queda se deve ao fraco volume de vendas, que, por sua vez, &eacute; reflexo das baixas demandas interna e externa, de acordo com o Cepea. &ldquo;Vale lembrar que as expo</p>','Alta-na-arroba-do-boi-nao-esta-refletindo-no-preco-das-carnes',NULL,'1591727977.1537370199.boi-de-corte.jpg','2018-07-12','2020-06-09 21:39:37','2020-06-09 21:39:37',NULL);
/*!40000 ALTER TABLE `noticias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `linha_id` int(10) unsigned NOT NULL,
  `indicacoes` text COLLATE utf8mb4_unicode_ci,
  `mododeusar` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagem` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `informacoesnutricionais` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produtos_linha_id_foreign` (`linha_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` (`id`, `nome`, `descricao`, `linha_id`, `indicacoes`, `mododeusar`, `slug`, `imagem`, `informacoesnutricionais`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Agrosal Reprodução',NULL,1,'<p>Agrosal Reprodu&ccedil;&atilde;o &eacute; um suplemento mineral indicado para vacas e novilhas, tanto no sistema de monta natural, quanto no regime de insemina&ccedil;&atilde;o artificial. O Agrosal Reprodu&ccedil;&atilde;o cont&eacute;m Quelato de Cromo que atua como fator anti-estresse, propiciando um melhor desempenho reprodutivo das matrizes, melhorando com isso o &iacute;ndice de fertilidade do plantel.</p>','<p>O Agrosal Reprodu&ccedil;&atilde;o deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-Reproducao','1591454415.1531397354.REPRODUCAO.png','1',NULL,'2020-06-06 17:40:15',NULL),(2,'Agrosal 80',NULL,1,'<p>Suplemento mineral indicado para bovinos de corte em geral. O agrosal 80 &eacute; fabricado com ingredientes de alta Biodisponibilidade, o que garante ao organismo do animal, um melhor aproveitamento dos minerais consumidos.</p>','<p>O Agrosal 80 deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-80','1591730145.1537360224.1531398083.80.png',NULL,'2020-06-09 22:15:46','2020-06-09 22:15:46',NULL),(3,'Agrosal 100',NULL,1,'<p>Suplemento mineral indicado para vacas leiteiras mantidas a pasto durante a esta&ccedil;&atilde;o das &aacute;guas, pois cont&eacute;m altas concentra&ccedil;&otilde;es de C&aacute;lcio, F&oacute;sforo, Magn&eacute;sio e Mangan&ecirc;s que s&atilde;o primordiais para aumentar a produ&ccedil;&atilde;o leiteira e melhorar a fertilidade.</p>','<p>O Agrosal 100 deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-100','1591730741.1537360249.1531399064.100.png',NULL,'2020-06-09 22:25:41','2020-06-09 22:25:41',NULL),(4,'Agrosal Equino',NULL,1,'<p>Suplemento mineral balanceado, indicado para ser oferecido aos Equ&iacute;deos em geral, de maneira a corrigir as defici&ecirc;ncias destes elementos em nossas pastagens, contribuindo assim com a melhoria no desempenho destes animais no dia-a-dia da propriedade.</p>','<p>Fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-Equino','1591731635.1537360282.1531400541.EQUIONO.png',NULL,'2020-06-09 22:40:35','2020-06-09 22:40:35',NULL),(5,'Agrosal 60',NULL,1,'<p>&Eacute; especialmente indicados para bovinos de Corte na fase final de recria e na fase de engorda, mantidos em boas pastagens.</p>','<p>O Agrosal 60 deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-60','1591731831.1537369978.1531397766.60.png',NULL,'2020-06-09 22:43:51','2020-06-09 22:43:51',NULL),(6,'Agrosal 85',NULL,1,'<p>&Eacute; indicado para rebanhos bovinos em geral, mantidos em pastagens pobres em minerais, especialmente o f&oacute;sforo. O AgroSal 85 &eacute; fabricado com ingredientes de alta biodisponibilidade, o que garante ao organismo do animal um melhor aproveitamento dos minerais consumidos.</p>','<p>O Agrosal 85 deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-85','1591737203.1537360236.1531398589.85.png',NULL,'2020-06-10 00:13:23','2020-06-10 00:13:23',NULL),(7,'Agrosal 160',NULL,1,'<p>&Eacute; um concentrado mineral indicado para bovinos de corte em geral desde que dilu&iacute;do ao cloreto de s&oacute;dio (sal comum) de acordo com as recomenda&ccedil;&otilde;es abaixo.</p>','<p>Catergoria Animal | Independente da Qualidade da Pastagem</p>\r\n<p>-&gt;Na Cria&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; |&nbsp;<strong>Misturar: 1 saco de Agrosal 160 (25kg) com 1 saco de Sal Comum (25kg) - Obtemos 80g de F&oacute;sforo.</strong></p>\r\n<p>-&gt;Na Recria&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;|&nbsp;<strong>Misturar: 2 sacos de Agrosal 160 (50kg) com 3 sacos de Sal Comum (75kg) - Obtemos 64g de F&oacute;sforo.</strong></p>\r\n<p>-&gt;Na Engorda&nbsp; &nbsp; &nbsp; &nbsp;|&nbsp;<strong>Misturar: 1 saco de Agrosal 160 (25kg) com 2 sacos de Sal Comum (50kg) - Obtemos 53,33g de F&oacute;sforo.</strong></p>','Agrosal-160','1591737313.1537360294.1531399384.160.png',NULL,'2020-06-10 00:15:13','2020-06-10 00:15:13',NULL),(8,'Agrosal Berro',NULL,1,'<p>O AGROSAL BERRO &eacute; um suplemento mineral pronto para uso. Cont&eacute;m altas concentra&ccedil;&otilde;es de macro e micro minerais essenciais para o desenvolvimento dos ovinos, proporcionando assim, melhora nos &iacute;ndices zoot&eacute;cnicos do plantel.</p>','<p>O Agrosal Berro deve ser fornecido puro e a vontade nos cochos cobertos.</p>','Agrosal-Berro','1591737595.1537360310.1531400812.BERRO.png',NULL,'2020-06-10 00:19:55','2020-06-10 00:19:55',NULL),(9,'Rações para Equinos',NULL,3,'<p>Ra&ccedil;&atilde;o balanceada para suplementar os requerimentos nutricionais de equ&iacute;deos que encontra-se sobre esfor&ccedil;o f&iacute;sico leve. Trata-se de um alimento para ser oferecido aos animais de trabalho, de maneira a amenizar as defici&ecirc;ncias nutricionais de nossas pastagens, proporcionando assim um melhor desempenho no dia a dia da propriedade.&nbsp;</p>','<p><strong>N&atilde;o fornecer o produtos a animais que est&atilde;o em jejum</strong>. Fornecer diariamente 1 a 2Kg/ animal.</p>','Racoes-para-Equinos','1591738568.1537360282.1531400541.EQUIONO.png',NULL,'2020-06-10 00:36:08','2020-06-10 00:48:14',NULL),(10,'Rações para Bovinos de Corte',NULL,3,'<p><strong>RA&Ccedil;&Atilde;O BOVIPEC</strong></p>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender bovinos de corte na fase de engorda. Deve ser fornecida &agrave; boiada estabulada (confinamento) a qual se quer maximizar o ganho de peso no mais curto espa&ccedil;o de tempo. Fornecer 1Kg para cada 100Kg de peso vivo. Utilizar cochos cobertos, com espa&ccedil;amento m&iacute;nimo de 40cm linear por animal.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 16%; NDT: 75%; C&aacute;lcio: 0,7%; F&oacute;sforo: 0,6%; Vit. E: 7,5mg; Vit. A: 5.000UI.</p>\r\n<h3>RA&Ccedil;&Atilde;O BOVIPEC GOLD</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender bovinos de corte de alta qualidade gen&eacute;tica, a qual se deseja potencializar o ganho de peso (sistema de cria&ccedil;&atilde;o intensivo). Possui promotor de crescimento que melhora o aproveitamento do alimento volumoso consumido. Fornecer 1Kg para cada 100Kg de peso vivo. Utilizar cochos cobertos, com espa&ccedil;amento m&iacute;nimo de 40cm linear por animal.&nbsp;N&atilde;o fornecer o produto a Equ&iacute;dios.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 18%; NDT: 75%; C&aacute;lcio: 0,7%; F&oacute;sforo: 0,6%; Monensina S&oacute;dica: 70mg.</p>\r\n<h3>RA&Ccedil;&Atilde;O AGROTOURO</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender os requerimentos nutricionais de Touros, promovendo uma melhora no desempenho reprodutivo, contribuindo diretamente nos &iacute;ndices de fertilidade da propriedade. Fornecer diariamente 0,5% do peso vivo por animal.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 12%; NDT: 75%; C&aacute;lcio: 1%; F&oacute;sforo: 0,8%.</p>\r\n<h3>N.P.R. (N&uacute;cleo para Ra&ccedil;&atilde;o)</h3>\r\n<p>Concentrado prot&eacute;ico mineral, formulado para ser misturado ao farelo de milho e fornecido aos bovinos durante o per&iacute;odo seco do ano. Misturar 25Kg do N.P.R. em 75Kg de farelo de milho, tendo assim uma ra&ccedil;&atilde;o com 25% de Prote&iacute;na e 70% de NDT. Fornecer na primeira semana 1Kg/ Animal/ Dia e apartir da segunda semana 2Kg/ Animal/ Dia.&nbsp;Jamais fornecer N.P.R. puro.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 70%; NDT: 30%; C&aacute;lcio: 50g; F&oacute;sforo: 20g.</p>',NULL,'Racoes-para-Bovinos-de-Corte','1591738894.1531406250.Sem imagem.png',NULL,'2020-06-10 00:41:34','2020-06-10 00:41:34',NULL),(11,'Rações para Ovinos',NULL,3,'<h2 style=\"text-align: center;\">RA&Ccedil;&Otilde;ES PARA OVINOS CRESCIMENTO</h2>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender os requerimentos nutricionais de Ovinos na fase de crescimento, fornecendo minerais, vitaminas, prote&iacute;nas e energia para um melhor desenvolvimento dos Borregos. Proporciona uma dieta mais equilibrada, contribuindo assim com a sa&uacute;de dos animais e o alcance de melhores &iacute;ndices zoot&eacute;cnicos. Cont&eacute;m aditivo para impedir a forma&ccedil;&atilde;o do c&aacute;lculo renal (Ur&oacute;litos). Fornecer diariamente de 0,5 a 1% do peso vivo.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 24%; NDT: 80%; C&aacute;lcio: 0,8%; F&oacute;sforo: 0,5%; Vit E: 7,5mg; Vit A: 5.000UI.</p>\r\n<h3>RA&Ccedil;&Otilde;ES PARA OVINOS ENGORDA</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender os requerimentos nutricionais de Ovinos na fase de engorda, fornecendo minerais, vitaminas, prote&iacute;nas e energia, o que proporciona uma dieta mais equilibrada, contribuindo assim com a sa&uacute;de dos animais e o alcance de melhores &iacute;ndices de ganho de peso. Cont&eacute;m aditivo para impedir a forma&ccedil;&atilde;o do c&aacute;lculo renal (Ur&oacute;litos). Fornecer diariamente de 0,5 a 1% do peso vivo.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 17%; NDT: 80%; C&aacute;lcio: 0,75%; F&oacute;sforo: 0,40%; Vit E: 7,5mg; Vit A: 5.000UI.</p>',NULL,'Racoes-para-Ovinos','1591738981.1531406250.Sem imagem.png',NULL,'2020-06-10 00:43:01','2020-06-10 00:43:01',NULL),(12,'Rações para Vacas Leiteiras',NULL,3,'<p>As ra&ccedil;&otilde;es Agroleite, fornecem minerais, prote&iacute;nas, vitaminas e energia, propiciando uma dieta mais equilibrada e contribuindo para que o rebanho alcance uma maior produtividade leiteira e tamb&eacute;m melhores &iacute;ndices de fertilidade. Utilizar cochos cobertos, com espa&ccedil;amento m&iacute;nimo de 40cm linear por animal.</p>\r\n<h3>Ra&ccedil;&atilde;o AGROLEITE 18%</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender rebanhos de m&eacute;dia a alta produ&ccedil;&atilde;o durante o per&iacute;odo das &aacute;guas. Fornecer diariamente 1kg da ra&ccedil;&atilde;o para cada 3 litros de leite produzido.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 18%; NDT: 80%; C&aacute;lcio: 0,75%; F&oacute;sforo: 0,55%.</p>\r\n<h3>Ra&ccedil;&atilde;o AGROLEITE 20%</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender rebanhos de alta produ&ccedil;&atilde;o durante o per&iacute;odo das &aacute;guas, ou rebanhos de m&eacute;dia produ&ccedil;&atilde;o durante a seca. Fornecer diariamente 1kg da ra&ccedil;&atilde;o para cada 3 litros de leite produzido.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto:</strong>&nbsp;PB: 20%; NDT: 77%; C&aacute;lcio: 0,80%; F&oacute;sforo: 0,60%.</p>\r\n<h3>Ra&ccedil;&atilde;o AGROLEITE 22%</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada para atender rebanhos de alta produ&ccedil;&atilde;o durante o per&iacute;odo da seca. Fornecer diariamente 1kg da ra&ccedil;&atilde;o para cada 3 litros de leite produzido.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 22%; NDT: 75%; C&aacute;lcio: 0,90%; F&oacute;sforo: 0,65%.</p>',NULL,'Racoes-para-Vacas-Leiteiras','1591739051.1531406250.Sem imagem.png',NULL,'2020-06-10 00:44:11','2020-06-10 00:44:11',NULL),(13,'Rações para Bezerros',NULL,3,'<h2 style=\"text-align: center;\">RA&Ccedil;&Atilde;O S&Oacute;-BABY</h2>\r\n<p>Ra&ccedil;&atilde;o balanceada enriquecida com vitaminas, ideal para ser oferecida aos Bezerros na fase inicial de aleitamento, apartir da segunda semana de vida at&eacute; os 3 meses de idade. Cont&eacute;m ingredientes de alta digestibilidade o que proporciona maior desenvolvimento ruminal, contribuindo assim para um desmame mais precoce, maior ganho de peso e uma melhora na condi&ccedil;&atilde;o corporal das matrizes. Cont&eacute;m Bacitracina de Zinco que auxilia no controle de diarr&eacute;ias bacterianas. O consumo di&aacute;rio estimado &eacute; de 0,5 a 1% do peso vivo. Fornecer em cochos cobertos. N&atilde;o cont&eacute;m Ur&eacute;ia.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 20%; NDT: 78%; C&aacute;lcio: 0,95%; F&oacute;sforo: 0,75%; Vit E: 7,5mg; Vit A: 10.000UI.</p>\r\n<h3>RA&Ccedil;&Atilde;O AGROBABY</h3>\r\n<p>Ra&ccedil;&atilde;o balanceada indicada para suplementar os requerimentos nutricionais Bezerros entre 3 a 8 meses de idade. Cont&eacute;m Bacitracina de Zinco que auxilia no controle de diarr&eacute;ias bacterianas. Promove um desenvolvimento mais precoce dos animais jovens e a recupera&ccedil;&atilde;o de animais debilitados, possibilitando antecipar o desmame al&eacute;m de auxiliar na melhora da condi&ccedil;&atilde;o corporal das matrizes. O consumo di&aacute;rio estimado &eacute; de 0,5 a 1% do peso vivo. Fornecer em cochos cobertos. Cont&eacute;m Ur&eacute;ia.</p>\r\n<p><strong>N&iacute;veis de Garantia por Kg do produto</strong>: PB: 18%; NDT: 75%; C&aacute;lcio: 1,6%; F&oacute;sforo: 1%.</p>',NULL,'Racoes-para-Bezerros','1591739108.1531406250.Sem imagem.png',NULL,'2020-06-10 00:45:08','2020-06-10 00:45:08',NULL),(14,'Nutrimais',NULL,2,'<p>Suplemento mineral prot&eacute;ico de baixo consumo, indicado para os bovinos em geral na &eacute;poca seca do ano. Cont&eacute;m uma alta concentra&ccedil;&atilde;o prot&eacute;ica imprescind&iacute;vel para amenizar os efeitos nocivos da seca propiciando com isso o fim do &ldquo;boi sanfona&rdquo;.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos de maneira que evite ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Na primeira semana de uso, &eacute; recomend&aacute;vel misturar NUTRIMAIS com o AgroSal 85 na propor&ccedil;&atilde;o de 1 por 1, para adapta&ccedil;&atilde;o dos animais.</li>\r\n<li>Consumo m&eacute;dio esperado em torno de 200 gramas/UA/dia.</li>\r\n<li>Manter sempre os cochos abastecidos com o produto.</li>\r\n</ul>','Nutrimais','1591739835.1537360326.1531401190.NUTRIMAIS-100.png',NULL,'2020-06-10 00:57:15','2020-06-10 00:57:15',NULL),(15,'Nutrimais 1000',NULL,2,'<p>Suplemento mineral prot&eacute;ico e energ&eacute;tico de alto consumo indicado para ser oferecido durante a seca, para a boiada em termina&ccedil;&atilde;o mantida a pasto. O Nutrimais 1000 propiciar&aacute; um melhor acabamento atrav&eacute;s de um maior ac&uacute;mulo de gordura na carca&ccedil;a. &Eacute; recomendado utiliz&aacute;-lo at&eacute; 45 dias antes do abate. O ganho de peso esperado &eacute; de 700 a 800 gramas ao dia, dependendo do estado nutricional, da gen&eacute;tica e das condi&ccedil;&otilde;es de manejo do gado e principalmente da qualidade e quantidade do alimento volumoso.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos de maneira que evite o ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Fornecer em torno de 1 Kg/UA/dia.</li>\r\n</ul>','Nutrimais-1000','1591740393.1537360356.1531402421.1000.png',NULL,'2020-06-10 01:06:33','2020-06-10 01:06:33',NULL),(16,'LactoSal',NULL,2,'<p>Suplemento mineral proteico e energ&eacute;tico de alto consumo para ser fornecido &agrave;s vacas leiteiras durante a esta&ccedil;&atilde;o seca. O Lactosal fornece minerais, proteinas, vitaminas e energia, que s&atilde;o essenciais para melhorar a produ&ccedil;&atilde;o de leite, a condi&ccedil;&atilde;o corporal e a fertilidade do plantel.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos com sistemas que evitem ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Na primeira semana de uso, &eacute; recomend&aacute;vel misturar LACTOSAL com o AgroSal 85 na propor&ccedil;&atilde;o de 1 por 1, para adapta&ccedil;&atilde;o dos animais.</li>\r\n<li>Fornecer regularmente em torno de 1Kg/vaca/dia.</li>\r\n</ul>','LactoSal','1591740455.1537360383.1531403373.LACTOSAL.png',NULL,'2020-06-10 01:07:35','2020-06-10 01:07:35',NULL),(17,'Agrosal Engorda Plus',NULL,2,'<p>Suplemento mineral prot&eacute;ico de baixo consumo, ideal para a suplementa&ccedil;&atilde;o de bovinos cruzados (cruzamento industrial) na fase de engorda, criados em regime de pasto.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos de maneira que evite o ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Na primeira semana de uso, &eacute; aconselh&aacute;vel misturar o produto com o Agrosal 85 para adapta&ccedil;&atilde;o dos animais &agrave; ur&eacute;ia.</li>\r\n<li>Consumo m&eacute;dio esperado em torno de 150g/ UA/ dia.</li>\r\n<li>Fornecer regularmente e &agrave; vontade.</li>\r\n</ul>','Agrosal-Engorda-Plus','1591740725.1531404043.ENGORDA.png',NULL,'2020-06-10 01:12:05','2020-06-10 01:12:05',NULL),(18,'Nutrimais 500',NULL,2,'<p>Suplemento mineral prot&eacute;ico e energ&eacute;tico de m&eacute;dio consumo, indicado aos bovinos de corte mantidos a pastos durante a esta&ccedil;&atilde;o seca do ano. O Nutrimais 500 ajuda a corrigir as defici&ecirc;ncias nutricionais predominantes nas pastagens, propiciando com isso, melhora no ganho de peso do gado.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos de maneira que evite ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Na primeira semana de uso, &eacute; recomend&aacute;vel misturar NUTRIMAIS 500 com o AgroSal 85 na propor&ccedil;&atilde;o de 1 por 1, para adapta&ccedil;&atilde;o dos animais.</li>\r\n<li>Consumo m&eacute;dio esperado em torno de 400 a 500 gramas/UA/dia.</li>\r\n</ul>','Nutrimais-500','1591740891.1537360342.1531401982.500.png',NULL,'2020-06-10 01:14:51','2020-06-10 01:14:51',NULL),(19,'Agrosal Leite Plus',NULL,2,'<p>Suplemento mineral prot&eacute;ico de baixo consumo para ser oferecidos &agrave;s vacas leiteiras durante o per&iacute;odo das &aacute;guas. O AgroSal Leite Plus, ajuda corrigir as defici&ecirc;ncias nutricionais de nossas pastagens. O AgroSal Leite Plus cont&eacute;m uma concentra&ccedil;&atilde;o prot&eacute;ica imprescind&iacute;vel para uma maior produ&ccedil;&atilde;o leiteira.</p>','<ul>\r\n<li>Fornecer o Produto sempre puro, em cochos cobertos de maneira que evite o ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Consumo m&eacute;dio esperado de 200g/UA/dia, dependendo da produtividade das vacas e estado nutricional da pastagem.</li>\r\n<li>Fornecer regularmente e &agrave; vontade.</li>\r\n</ul>','Agrosal-Leite-Plus','1591741099.1537360371.1531403115.LEITE-+-PLUS.png',NULL,'2020-06-10 01:18:19','2020-06-10 01:18:19',NULL),(20,'Agrosal Engorda',NULL,2,'<p>Suplemento mineral prot&eacute;ico de baixo consumo, indicado &agrave; bovinos na fase de termina&ccedil;&atilde;o para suplementar as car&ecirc;ncias prot&eacute;ico-minerais de pastagens degradadas.</p>','<ul>\r\n<li>Fornecer o produto sempre em cochos cobertos de maneira que evite o ac&uacute;mulo de &aacute;gua.</li>\r\n<li>Consumo m&eacute;dio esperado em torno de 100 a 120 gramas/UA/dia, dependendo do estado nutricional do gado e das condi&ccedil;&otilde;es em que se encontra o pasto.</li>\r\n<li>Fornecer regularmente e &agrave; vontade.</li>\r\n</ul>','Agrosal-Engorda','1591741288.1537360398.1531403717.ENGORDA.png',NULL,'2020-06-10 01:21:28','2020-06-10 01:21:28',NULL),(21,'AgroSalinho',NULL,2,'<p>Suplemento mineral prot&eacute;ico (sem ur&eacute;ia) e energ&eacute;tico, para ser oferecido aos bezerros em amamenta&ccedil;&atilde;o e tamb&eacute;m para bezerros debilitados. O Agrosalinho estimula o desenvolvimento ruminal, corrige defici&ecirc;ncias nutricionais propiciando uma bezerrada mais pesada, precoce e sadia. Cont&eacute;m Bacitracina de Zinco que ajuda no controle de diarr&eacute;ias bacterianas.</p>','<p>O agrosalinho deve ser colocado puro em cochos cobertos exclusivos para bezerros (Creep &ndash; Feeding) e servido &agrave; vontade.</p>','AgroSalinho','1591741431.1537360427.1531404252.AGROSALINHO.png',NULL,'2020-06-10 01:23:51','2020-06-10 01:23:51',NULL);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quemsomos`
--

DROP TABLE IF EXISTS `quemsomos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quemsomos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `razaosocial` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomefantasia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ie` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quemsomos` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sac` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `tradicao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tecnologia` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inovacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quemsomos`
--

LOCK TABLES `quemsomos` WRITE;
/*!40000 ALTER TABLE `quemsomos` DISABLE KEYS */;
INSERT INTO `quemsomos` (`id`, `razaosocial`, `nomefantasia`, `cnpj`, `ie`, `quemsomos`, `email`, `telefone`, `fax`, `sac`, `endereco`, `bairro`, `cidade`, `estado`, `cep`, `facebook`, `instagram`, `youtube`, `created_at`, `updated_at`, `deleted_at`, `tradicao`, `tecnologia`, `inovacao`) VALUES (1,'Nutrientes Agro Sal Ltda','Agrosal','03.873.378/0001-98',NULL,'<p>Sob a supervis&atilde;o do Prof. D&eacute;cio Sousa Gra&ccedil;a, PhD em nutri&ccedil;&atilde;o animal pela Universidade de Aberdeen na Esc&oacute;cia, vem apresentando solu&ccedil;&otilde;es criativas para suprir as defici&ecirc;ncias nutricionais dos bovinos que ocorrem nos diferentes sistemas de produ&ccedil;&atilde;o, tanto na pecu&aacute;ria de corte, quanto na leiteira.</p>','agrosal@nutrientesagrosal.com.br','(99) 3525-4321',NULL,NULL,'Rodovia BR 010 (Belém-Brasília), Km 1352,','Coco Grande','Imperatriz','MA','65.917-220','https://m.me/nutrientesagrosal',NULL,NULL,'2020-06-06 16:21:04','2020-06-06 16:21:04',NULL,'A AGROSAL, desde 1987, com seriedade e competência, vem produzindo alternativas de manejo nutricional para melhorar a produtividade da pecuária.','A AGROSAL produz suplementos de minerais, proteinados e rações para atender as mais variadas situações de nutrição animal aplicada. Oferece Produtos de Qualidade que estimulam o desempenho dos animais no crescimento, na engorda, na lactação e na reprodução, ao mesmo tempo que melhoram a resistência dos animais às infecções.','Buscando novos horizontes com uma administração voltada para atender as necessidades de seus clientes.');
/*!40000 ALTER TABLE `quemsomos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `nome`, `email`, `password`, `nivel`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Marcos Vinícius','marcos@likepublicidade.com','$2y$10$dtEfa8frKcGCOzEpIdg8xuqyc48s4sDgHi6Un.kHGR4DEljMQJo62',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nutrient_db'
--

--
-- Dumping routines for database 'nutrient_db'
--
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-10 10:45:34
